/* remove values that are not related to business.
 * Diversity, Equity, Inclusion   
 * ©²
 */
 
//get all elements in html dom using wildcard
const myWebElements = document.getElementsByTagName('*');

const pattern = /Diversity|Inclusion|Equity/;
let myMatches = [];
let position;

for (let i=0; i<myWebElements.length; i++) {
	//let position = pattern.exec(myWebElements[i].firstChild.textContent);
	position = pattern.exec(myWebElements[i].innerText);
	if (position) {
		//console.log(myWebElements[i].innerText.length);
		if (myWebElements[i].innerText.length > 8 && myWebElements[i].innerText.length < 50) {
			console.log(myWebElements[i].innerText);
			myMatches.push(i);
			//myMatches.push(position.index);
		}
		//myMatches.push(position.index);
	}
}

//console.log(myMatches.length);
let element_index;

for (let j=0; j < myMatches.length; j++ ) {
	//console.log(myMatches[j]);
	element_index = myMatches[j];
	if (element_index) {

		//console.log(element_index);//why does this return the whole collection when it is a #?
			
		if (myWebElements[element_index]) {
			//console.log(myWebElements[element_index]);
			myWebElements[element_index].style.scale = 0;
			//myWebElements[element_index].style.zIndex = -999;
			myWebElements[element_index].style.height = 0;
                        myWebElements[element_index].style.width = 0;

		}
	}
}
