/* Never Ending Emergency Removal
 * Remove never ending emergency banners online. 
 * ©²
 */
 
//tested on ca.gov and namecheap.com

//get all elements in html dom using wildcard
const myWebElements = document.getElementsByTagName('*');

console.log(myWebElements);


// We stand with our friends and colleagues in Ukraine
// For more information on COVID in California

const pattern = /Ukraine*|information on COVID*/;
	// /We stand with\w{} in Ukraine*|
	///For more information on COVID in California*/
	//|We stand with our friends and colleagues in Ukraine*/;
let myMatches = [];
let position;

for (let i=0; i<myWebElements.length; i++) {
	//let position = pattern.exec(myWebElements[i].firstChild.textContent);
	position = pattern.exec(myWebElements[i].innerText);
	if (position) {
		//console.log(myWebElements[i].innerText.length);
		if (myWebElements[i].innerText.length > 50 && myWebElements[i].innerText.length < 150) {
			console.log(myWebElements[i].innerText);
			myMatches.push(i);
			//myMatches.push(position.index);
		}
		//myMatches.push(position.index);
	}
}

//console.log(myMatches.length);
let element_index;

for (let j=0; j < myMatches.length; j++ ) {
	//console.log(myMatches[j]);
	element_index = myMatches[j];
	if (element_index) {

		//console.log(element_index);//why does this return the whole collection when is a #?
			
		if (myWebElements[element_index]) {
			//console.log(myWebElements[element_index]);
			myWebElements[element_index].style.scale = 0;
			//myWebElements[element_index].style.zIndex = -999;
			myWebElements[element_index].style.height = 0;
                        myWebElements[element_index].style.width = 0;

		}
	}
}

